package pl.edu.vistula.myfirstjavaspringproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstJavaSpringProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
