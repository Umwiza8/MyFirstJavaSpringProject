package pl.edu.vistula.myfirstjavaspringproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstJavaSpringProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyFirstJavaSpringProjectApplication.class, args);
    }

}
